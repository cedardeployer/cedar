#!/usr/bin/python

from __future__ import print_function

import re
import os
import sys

# import logging
# import pymysql
import json
import boto3
from boto3.dynamodb.conditions import Key, Attr
# from slacker import Slacker
# import unidecode
from botocore.exceptions import ClientError
from datetime import date, datetime
import hashlib

# app_name = fba-open-api
# app_username = open-api-user
# policyport_username = fba-open-api-user
# timestamp = 1632545355
# key=7fe479dd06bcc193b3dc37bd56060ce016d25e4b
# ft-api-key=df4aee2042e1e1ae144a5c3b03b51ba2

# app_name = "fba-open-api"
# app_username = "open-api-user"
# policyport_username = "fba-open-api-user"
# ft_api_key="df4aee2042e1e1ae144a5c3b03b51ba2"
# clientKey = "90d9869a1102ccf543fccd62f25d04ffdd4fd911"
# attributes = ""
# timestamp = 1632545355
# keyValue = app_name + "|" + app_username + "|" + policyport_username + "|" + timestamp + "|" + attributes + "|" + clientKey
# queryAuth = "app_name=" + app_name + "&app_username=" + app_username + "&policyport_username=" + policyport_username + "&timestamp=" + timestamp + "&key=" + key + "&ft-api-key=" + ft_api_key;
# hash_object = hashlib.sha1(b'keyValue')
client_key = "90d9869a1102ccf543fccd62f25d04ffdd4fd911"
responses = {"member_exist": "Member already exists",
             "member_exist_db": "Member already exists in database",
             "member_state_exception": "Exception in persisting member in database",
             "member_not_exist": "Member does not exist",
             "member_not_found": "Member not found"
             }

dynamo_table = "pp_membership_api"
dynamo_resource = boto3.resource('dynamodb')


def dynamoGenericGet(PK, ft_api_key, LastEvaluatedKey=None):
    tbl = dynamo_resource.Table(dynamo_table)
    combined = ft_api_key
    pkCombined = "%s_open" % (PK)
    get_params = {"KeyConditionExpression": Key('PK').eq(pkCombined) & Key('SK1').begins_with(combined),
                  "FilterExpression": Attr('deleted').ne(True) | Attr('deleted').not_exists()}
    try:
        results = tbl.query(**get_params)
        return results['Items']
    except ClientError as ex:
        msg = "[E] -GET-  DynamoDB get of LSI-SK:%s  error:%s" % (pkCombined, ex)
        print(msg)
    return None


# var queryAuth = "app_name=" + app_name + "&app_username=" + app_username + "&policyport_username=" + policyport_username + "&timestamp=" + timestamp + "&key=" + key + "&ft-api-key=" + ft_api_key
def verify_keys(event, LastEvaluatedKey=None, test=False):
    clientKey = client_key
    queryStringParameters = event['queryStringParameters']

    attributes = ""
    app_name = queryStringParameters['app_name']
    app_username = queryStringParameters['app_username']
    policyport_username = queryStringParameters['policyport_username']
    timestamp = queryStringParameters['timestamp']
    if not test:
        ft_api_key = queryStringParameters['ft-api-key']
        key = queryStringParameters['key']

    if test and 'clientKey' in queryStringParameters:
        clientKey = queryStringParameters['clientKey']
    if not test:
        print("=========-----START--=====--Authorize--====-uname=%s-======--===ft_api_key=%s======" % (app_username, ft_api_key))
        items = dynamoGenericGet("membership_keys", ft_api_key)
        if not items:
            print("[E] this api ft_api_key:%s not valid" % (ft_api_key))
            raise Exception('Unauthorized')
    keyValue = app_name + "|" + app_username + "|" + policyport_username + "|" + timestamp + "|" + attributes + "|" + clientKey
    #######################################################
    #### START  ##### GET MEMBERSHIP & VALIDATE SHA ########
    #######################################################
    hash_object = hashlib.sha1(keyValue.encode())
    gen = hash_object.hexdigest()
    if test:
        if not timestamp:
            return None
        return gen
    if '"' in key:
        key = key.replace('"','')
    print("key in:%s....  and key gen:%s" % (key, gen))
    if gen != key:
        print("[E] this api key:%s does NOT match gen:%s" % (key, gen))
        raise Exception('Unauthorized')
    return None


def lambda_handler(event, context):
    print(event)
    response = None
    test = False

    if 'action' in event:
        if 'test' in event['action']:
            return verify_keys(event, None, True)

    # bucket=os.environ['bucket']
    # db_name=os.environ['db_name']
    # name=os.environ['db_username']
    # rds_host=os.environ['rds_host']
    # password=os.environ['db_password']
    # userpoolID = os.environ['userpoolID']
    headers = event['headers']
    identity = event['requestContext']['identity']

    # requestCountry = headers['CloudFront-Viewer-Country']
    # key=headers['x-api-key']
    # apiKeyId = identity['apiKeyId']
    sourceIp = identity['sourceIp']
    verify_keys(event)

    #######################################################
    #### END  ##### GET MEMBERSHIP & VALIDATE SHA   ########
    #######################################################

    # if not requestCountry.lower() is 'us':
    #     print("not us user")
    username = event['queryStringParameters']['ft-api-key']
    # principalId = 'user|a1b2c3d4'
    principalId = 'user|%s' % (username)

    tmp = event['methodArn'].split(':')
    apiGatewayArnTmp = tmp[5].split('/')
    awsAccountId = tmp[4]

    ##############################################################################
    """keep in mind, the policy is cached for 5 minutes by default (TTL is configurable in the authorizer)"""
    """and will apply to subsequent calls to any method/resource in the RestApi"""
    """made with the same token"""
    ##############################################################################
    policy = AuthPolicy(principalId, awsAccountId)
    policy.restApiId = apiGatewayArnTmp[0]
    policy.region = tmp[3]
    policy.stage = apiGatewayArnTmp[1]
    # policy.denyAllMethods()

    # policy.allowMethod(HttpVerb.GET, '/nebula/*')
    # policy.allowMethod(HttpVerb.GET, '/PPort/*')
    policy.allowMethod(HttpVerb.ALL, '*')

    # Finally, build the policy
    authResponse = policy.build()

    # new! -- add additional key-value pairs associated with the authenticated principal
    # these are made available by APIGW like so: $context.authorizer.<key>
    # additional context is cached
    # context = {
    #     'PortalID': key_pid,  # $context.authorizer.key -> value
    #     'UserID': userid
    # }

    context = {**event['queryStringParameters']}

    authResponse['context'] = context
    print("============---------FINISH--=====----====--======--=========")
    print(authResponse)
    return authResponse


###################################################################
######## AMAZON SPECIFIC CODE BELOW ###############################
################# DO NOT TOUCH !!!! ###############################
###################################################################
class HttpVerb:
    GET = 'GET'
    POST = 'POST'
    PUT = 'PUT'
    PATCH = 'PATCH'
    HEAD = 'HEAD'
    DELETE = 'DELETE'
    OPTIONS = 'OPTIONS'
    ALL = '*'


class AuthPolicy(object):
    # The AWS account id the policy will be generated for. This is used to create the method ARNs.
    awsAccountId = ''
    # The principal used for the policy, this should be a unique identifier for the end user.
    principalId = ''
    # The policy version used for the evaluation. This should always be '2012-10-17'
    version = '2012-10-17'
    # The regular expression used to validate resource paths for the policy
    pathRegex = '^[/.a-zA-Z0-9-\*]+$'

    '''Internal lists of allowed and denied methods.

    These are lists of objects and each object has 2 properties: A resource
    ARN and a nullable conditions statement. The build method processes these
    lists and generates the approriate statements for the final policy.
    '''
    allowMethods = []
    denyMethods = []

    # The API Gateway API id. By default this is set to '*'
    restApiId = '*'
    # The region where the API is deployed. By default this is set to '*'
    region = '*'
    # The name of the stage used in the policy. By default this is set to '*'
    stage = '*'

    def __init__(self, principal, awsAccountId):
        self.awsAccountId = awsAccountId
        self.principalId = principal
        self.allowMethods = []
        self.denyMethods = []

    def _addMethod(self, effect, verb, resource, conditions):
        '''Adds a method to the internal lists of allowed or denied methods. Each object in
        the internal list contains a resource ARN and a condition statement. The condition
        statement can be null.'''
        if verb != '*' and not hasattr(HttpVerb, verb):
            raise NameError('Invalid HTTP verb ' + verb + '. Allowed verbs in HttpVerb class')
        resourcePattern = re.compile(self.pathRegex)
        if not resourcePattern.match(resource):
            raise NameError('Invalid resource path: ' + resource + '. Path should match ' + self.pathRegex)

        if resource[:1] == '/':
            resource = resource[1:]

        resourceArn = 'arn:aws:execute-api:{}:{}:{}/{}/{}/{}'.format(self.region, self.awsAccountId, self.restApiId, self.stage, verb, resource)

        if effect.lower() == 'allow':
            self.allowMethods.append({
                'resourceArn': resourceArn,
                'conditions': conditions
            })
        elif effect.lower() == 'deny':
            self.denyMethods.append({
                'resourceArn': resourceArn,
                'conditions': conditions
            })

    def _getEmptyStatement(self, effect):
        '''Returns an empty statement object prepopulated with the correct action and the
        desired effect.'''
        statement = {
            'Action': 'execute-api:Invoke',
            'Effect': effect[:1].upper() + effect[1:].lower(),
            'Resource': []
        }

        return statement

    def _getStatementForEffect(self, effect, methods):
        '''This function loops over an array of objects containing a resourceArn and
        conditions statement and generates the array of statements for the policy.'''
        statements = []

        if len(methods) > 0:
            statement = self._getEmptyStatement(effect)

            for curMethod in methods:
                if curMethod['conditions'] is None or len(curMethod['conditions']) == 0:
                    statement['Resource'].append(curMethod['resourceArn'])
                else:
                    conditionalStatement = self._getEmptyStatement(effect)
                    conditionalStatement['Resource'].append(curMethod['resourceArn'])
                    conditionalStatement['Condition'] = curMethod['conditions']
                    statements.append(conditionalStatement)

            if statement['Resource']:
                statements.append(statement)

        return statements

    def allowAllMethods(self):
        '''Adds a '*' allow to the policy to authorize access to all methods of an API'''
        self._addMethod('Allow', HttpVerb.ALL, '*', [])

    def denyAllMethods(self):
        '''Adds a '*' allow to the policy to deny access to all methods of an API'''
        self._addMethod('Deny', HttpVerb.ALL, '*', [])

    def allowMethod(self, verb, resource):
        '''Adds an API Gateway method (Http verb + Resource path) to the list of allowed
        methods for the policy'''
        self._addMethod('Allow', verb, resource, [])

    def denyMethod(self, verb, resource):
        '''Adds an API Gateway method (Http verb + Resource path) to the list of denied
        methods for the policy'''
        self._addMethod('Deny', verb, resource, [])

    def allowMethodWithConditions(self, verb, resource, conditions):
        '''Adds an API Gateway method (Http verb + Resource path) to the list of allowed
        methods and includes a condition for the policy statement. More on AWS policy
        conditions here: http://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_elements.html#Condition'''
        self._addMethod('Allow', verb, resource, conditions)

    def denyMethodWithConditions(self, verb, resource, conditions):
        '''Adds an API Gateway method (Http verb + Resource path) to the list of denied
        methods and includes a condition for the policy statement. More on AWS policy
        conditions here: http://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_elements.html#Condition'''
        self._addMethod('Deny', verb, resource, conditions)

    def build(self):
        '''Generates the policy document based on the internal lists of allowed and denied
        conditions. This will generate a policy with two main statements for the effect:
        one statement for Allow and one statement for Deny.
        Methods that includes conditions will have their own statement in the policy.'''
        if ((self.allowMethods is None or len(self.allowMethods) == 0) and
                (self.denyMethods is None or len(self.denyMethods) == 0)):
            raise NameError('No statements defined for the policy')

        policy = {
            'principalId': self.principalId,
            'policyDocument': {
                'Version': self.version,
                'Statement': []
            }
        }

        policy['policyDocument']['Statement'].extend(self._getStatementForEffect('Allow', self.allowMethods))
        policy['policyDocument']['Statement'].extend(self._getStatementForEffect('Deny', self.denyMethods))

        return policy

###################################################################
######## AMAZON SPECIFIC CODE ABOVE ###############################
################# DO NOT TOUCH !!!! ###############################
###################################################################


if __name__ == '__main__':
    test = True
    print("============---------START--=====----====--======--=========")
    print("============---------FINISH--=====----====--======--=========")
    print("                      -*-                   ")
    print("============------START AUTHORIZER--=====----====--======--=========")

    # print(emails)
