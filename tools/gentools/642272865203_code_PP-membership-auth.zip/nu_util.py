import functools
import os
import time
import sys

from datetime import datetime, timedelta, time
from typing import List

import logging
import sentry_sdk
import boto3
from botocore.exceptions import ClientError
from sentry_sdk import add_breadcrumb

# region -- logging --


class MyDateTimeFormatter(logging.Formatter):
    import datetime as dt
    converter = dt.datetime.fromtimestamp

    def formatTime(self, record, datefmt=None):
        ct = self.converter(record.created)
        if datefmt:
            s = ct.strftime(datefmt)
        else:
            t = ct.strftime("%Y-%m-%dT%H:%M:%S.")
            s = t + ("%02d" % (record.msecs)) + "Z"
        return s


isloggingloaded = False
running_inside_lambda = False


def setup_logging(lvl=logging.DEBUG):
    global isloggingloaded, running_inside_lambda
    if isloggingloaded:
        return

    logging.getLogger('boto3').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('botocore').setLevel(logging.WARNING)
    logging.getLogger('nose').setLevel(logging.WARNING)
    logging.getLogger('pynamodb').setLevel(logging.WARNING)
    logging.getLogger('s3transfer').setLevel(logging.WARNING)

    # add stdout handler
    root = logging.getLogger()
    root.setLevel(lvl)

    # see if aws added it's own handler, and if so - say i
    for handler in root.handlers:
        handlertype = str(type(handler))
        print(f"handlertype: {handlertype}")
        if handlertype == "<class 'bootstrap.LambdaLoggerHandler'>":
            print("-- lambda handler found!! -- ")
            running_inside_lambda = True

    strFormat = "[%(levelname)s] %(asctime)s _ %(message)s"
    if not running_inside_lambda:
        print(" -- not in lambda --")
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(lvl)
        handler.setFormatter(MyDateTimeFormatter(strFormat))
        root.addHandler(handler)

#		print("[DEBUG]	2020-01-28T20:44:31.35Z	961e3f1b-7b4f-43e2-b26f-7e798f7a2ddd	should be")
#		logging.debug("actually is")

    # root.setFormat(strFormat)
        # logging.basicConfig(level=logging.DEBUG)
        # logging.basicConfig(level=lvl, format=strFormat)

    isloggingloaded = True


def setup_logging_old(lvl=logging.DEBUG):
    global isloggingloaded
    if isloggingloaded:
        return

    logging.getLogger('boto3').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('botocore').setLevel(logging.WARNING)
    logging.getLogger('nose').setLevel(logging.WARNING)
    logging.getLogger('pynamodb').setLevel(logging.WARNING)
    logging.getLogger('s3transfer').setLevel(logging.WARNING)

    strFormat = "[%(asctime)s] %(name)s %(levelname)s:  %(message)s"
    # logging.basicConfig(level=logging.DEBUG)
    #logging.basicConfig(level=lvl, format=strFormat)

    # add stdout handler
    root = logging.getLogger()
    root.setLevel(lvl)

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(lvl)
    handler.setFormatter(logging.Formatter(strFormat))
    root.addHandler(handler)

    isloggingloaded = True

# endregion


def setup_sentry():
    from sentry_sdk.integrations.aws_lambda import AwsLambdaIntegration
    env = os.environ['env'] if 'env' in os.environ else 'dev'
    dsn = os.environ['sentry_dsn'] if 'sentry_dsn' in os.environ \
        else 'https://c71b9071844e47b89aa029598fbbb9f8@o1022223.ingest.sentry.io/5988348'  # catch-all project

    sentry_sdk.init(
        dsn=dsn,
        integrations=[AwsLambdaIntegration()],
        environment=env
    )


def getcounter(countername):
    from model.nucpolicyport_model import Counters
    # logging.info("  -- generating new key for: {}".format(countername).format(countername))

    # get counter
    cntr = next(Counters.query(countername), None)

    if cntr is None:
        raise ValueError(f"Counter not defined/started for table {countername}")

    res = cntr.update(actions=[Counters.value.set(Counters.value + 1)])

    ret = int(res['Attributes']['value']['N'])
    return ret


def toUTC(date) -> datetime:
    """
    Convert dates to UTC. 
            - if empty, return empty
            - if string, convert to date first
    :param date: 
    :type date: 
    :return: datetime in UTC timezone
    :rtype: datetime
    """
    # if none, just return none
    if date is None:
        return None
    if isinstance(date, str):
        from dateutil import parser
        date = parser.parse(date)

    tzname = date.tzinfo.tzname(date) if date.tzinfo is not None else None
    if tzname is not None and date.tzinfo.tzname(date) == 'UTC':
        return date  # already in utc

#	logging.debug(f"toUTC date: {date}, tzname: {tzname}")

    # TODO: don't change anymore! just assume everything is UTC already anyway
    return date

    #	logging.debug(f"toUTC date: {date}, tzname: {tzname}")
    #
    # tz support
    # import pytz
    # tz_est = pytz.timezone('America/New_York')
    # tz_utc = pytz.UTC


# d = tz_est.localize(date)
    # return d.astimezone(tz_utc)


def toUTC_epoch(date) -> int:
    import calendar
    dt = toUTC(date)
    return calendar.timegm(dt.utctimetuple()) if dt is not None else None


def addYears(date: datetime, years: int):
    days2add = 0
    for i in range(years):
        days = 365
        dt = date + timedelta(days2add + days)
        if dt.day == date.day:
            days2add = days2add + days
        else:  # this is leap year add 1
            days2add = days2add + days + 1
    return date + timedelta(days2add)


def get_ttl():
    return toUTC_epoch(addYears(datetime.now(), 1))


def get_timestamp():
    import calendar
    dt = datetime.utcnow()
    mytimestamp = calendar.timegm(dt.utctimetuple())
    return mytimestamp


def get_import_user(portalid: str):
    from model.nucpolicyport_model import User, Portal, Role
    mytimestamp = get_timestamp()
    ttl = get_ttl()

    # find the user!
    user = next(User.query(User.gethashkey(portalid), User.SK1.startswith('user_'), User.username == 'dataimport', consistent_read=True), None)

    if user is None:
        # check if portal exists at all

        portal = Portal.get(Portal.gethashkey(), Portal.getrangekey(portalid))
        if portal is None:
            raise ValueError(f"PortalID not found: {portalid}")

        logging.debug("DataImport user is not found. Creating..")

        userid = getcounter(User.counter_name)
        roleid = getcounter(Role.counter_name)
        user = User(User.gethashkey(portalid), User.getrangekey(userid), userid=userid, username="dataimport",
                    email="robert.colvin@teamfocusins.com", roles=[roleid], first="dataimport", last="dataimport",  password='none',
                    createdon=mytimestamp, updatedon=mytimestamp, TTL_epoch=ttl,
                    createdby=userid, updatedby=userid)
        user.save()

        # role
        role = Role(Role.gethashkey(portalid), Role.getrangekey(roleid), portalid=portalid, roleid=roleid,
                    createdby=userid, createdon=mytimestamp, updatedby=userid, updatedon=mytimestamp, TTL_epoch=ttl,
                    name='dataimport', desc='dataimport')
        role.save()

        logging.debug('DataImport user was missing, created')

    return user


default_built_in_fields = {'PK', 'SK1', 'LSI_SK', 'deleted', 'TTL_epoch', 'createdby', 'createdon', 'updatedby', 'updatedon', 'portalid', 'policyid', 'attribute_values'}


def dynamodb_obj_has_data(obj, built_in_fields: List = []):
    """
    See if dynamodb item has actual data (outside of our default attributes, such as keys, creation tags, etc)
    """
    from model.nucpolicyport_model import Model
    if not isinstance(obj, Model):
        raise ValueError('Object passed in is not a dynamodb model!')

    proplist = default_built_in_fields.copy()
    for o in built_in_fields:
        proplist.add(o)

    # process list (if objects found, recursively iterate
    for p in obj.attribute_values:
        if p in proplist:
            continue  # already known property, ignore

        val = getattr(obj, p)
        if val is None:
            continue  # empty / doesn't count

        if isinstance(val, list) and len(val) > 0:
            return True  # for now, no recursion, just return confirmation if list is non-empty

        if isinstance(val, dict):
            return True  # for now, don't worry what object the mapattribute is, return true if non-empty

        logging.debug(f' -- {str(obj.__class__)}: found extra property with value: obj[{p}]={getattr(obj, p)}')
        return True

    return False


def datetime_from_ts(ts: int):
    if ts is None:
        return None

    return datetime.fromtimestamp(ts)


def get_extension(filepath: str):
    splitted = os.path.splitext(filepath)[1]
    if len(splitted) > 1:
        return f".{splitted[1:]}"

    return None


def s3_file_exists(bucket, path):
    s3 = boto3.client('s3')

    try:
        s3.head_object(Bucket=bucket, Key=path)
    except ClientError as ex:
        if ex.response['Error']['Code'] == '404':  # "NoSuchKey":
            return False
        else:
            logging.debug(f"in s3_file_exists, actual code returned: {ex.response['Error']['Code']}")
            raise ex

    return True


def ifnull(coll: dict, key: str, default=None):
    """
    Check if attributue in collection is null, if so return default, otherwise return value
    :param coll: Collection 
    :type coll: Dict
    :param key: Attribute to check
    :type key: str
    :param default: Default value to put there
    :type default: 
    :return: value of type needed
    :rtype: 
    """
    return coll[key] if coll is not None and key is not None and key in coll else default


def to_dynamo_json(data):
    import json
    from dynamodb_json import json_util as json_d

    item = json_d.dumps(data)  # String
    item = json.loads(item)  # Pythonn DYnamoJSON

    return item

#########################################################
##
# Decorators
##


def timer(func):
    """
    Print the runtime of the decorated function
    """

    @functools.wraps(func)
    def wrapper_timer(*args, **kwargs):
        start_time = time.perf_counter()
        value = func(*args, **kwargs)
        end_time = time.perf_counter()
        run_time = end_time - start_time
        print(f"Finished {func.__name__!r} in {run_time:.4f} seconds")
        return value

    return wrapper_timer


if __name__ == "__main__":
    setup_logging()
    # print(logging.Logger.manager.loggerDict)
    logging.debug('test msg')
    exit(0)


