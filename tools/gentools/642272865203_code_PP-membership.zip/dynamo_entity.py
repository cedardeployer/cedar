# zip -r -X auth001.zip ./
# python3 -m venv <myenvname>
# #https://davidhamann.de/2017/01/27/import-issues-running-python-aws-lambda/
import re
import os
import sys
import time


import json
import boto3
from boto3.dynamodb import types
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key, Attr


import boto3
import json
import datetime
import logging
import uuid
import re
# from datetime import datetime
from decimal import Decimal
from boto3.dynamodb.types import *
from microUtils import CommonEncoder

from dynamodb_json import json_util as json_d
logging.basicConfig(format='%(asctime)-15s %(message)s')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def addYears(date, years):
    days2add = 0
    for i in range(years):
        days = 365
        dt = date + datetime.timedelta(days2add + days)
        if dt.day == date.day:
            days2add = days2add + days
        else:  # this is leap year add 1
            days2add = days2add + days + 1
            print("leap year found %s" % (dt.year))
    return date + datetime.timedelta(days2add)


class DynamoEntity():
    client = None

    def __init__(self):
        self.DEBUG = False
        self.client = self.get_db_client()

    def create_entity(self, event, context):
        """
        Create new item
        NOTE: auto-tags with createdon/by and updatedon/by
        """

        if 'userid' not in event:
            return self.nu_response(False, 'userid not provided')
        if 'TableName' not in event:
            return self.nu_response(False, 'TableName not provided')

        logger.info("'Create' called. event: {0}".format(json.dumps(event)))

        db = self.get_db_client()

        # generate ids if required
        newid = None
        if 'autogen' in event:
            autoGEN = event['autogen']
            if 'attribute_name' not in autoGEN:
                raise ("Must specify attribute name to autogenerate")

            logger.info("Table is {0}".format(event['TableName']))
            logger.info('Getting id for {0}.{1}'.format(event['TableName'], autoGEN['attribute_name']))
            ctable = event['TableName']
            if 'CounterTable' in event:
                ctable = event['CounterTable']
            newid = nID = self.getcounter(ctable)
            # if 'secondary_name' in autoGEN:
            #     if 'secondary_prefix' in autoGEN:
            #         event['Item'][autoGEN['secondary_name']] = "%s%s"%(autoGEN['secondary_prefix'],nID)
            #     else:
            #         event['Item'][autoGEN['secondary_name']] = nID
            # if 'prefix' in event['autogen']:
            #     newid="%s%s"%(autoGEN['prefix'], nID)

            logger.info("New id: {0}".format(newid))

            event['Item'][event['autogen']['attribute_name']] = newid

            # logger.info('Generated ID for {0}.{1}: {2}'.format(
            #     event['TableName'],
            #     event['autogen']['attribute_name'],
            #     event['Item'][event['autogen']['attribute_name']]))

        ######################
        # tag with metadata
        if 'portalid' in event:
            if not 'portalid' in event['Item']:
                event['Item']['portalid'] = event['portalid']
        createdate = int(datetime.datetime.utcnow().timestamp())
        event['Item']['createdon'] = createdate
        event['Item']['createdby'] = event['userid']
        event['Item']['updatedon'] = createdate
        event['Item']['updatedby'] = event['userid']
        if not 'TTL_epoch' in event['Item']:
            TTL_raw = datetime.datetime.utcnow()
            epoch = datetime.datetime.utcfromtimestamp(0)
            ttl_date = addYears(TTL_raw, 7)
            TTL = int((ttl_date - epoch).total_seconds())
            event['Item']['TTL_epoch'] = TTL
        # get ref to items
        item = {k: v for k, v in event['Item'].items()}

        #######################################
        # check mandatory fields if specified
        if 'RequiredFields' in event:
            for field in event['RequiredFields']:
                if field not in item:
                    raise ValueError(f"Required field missing from item: {field}")

        ###############################
        # process compount attributes
        compounds = []
        if 'compound_attribute' in event:
            compounds.append(event['compound_attribute'])
        if 'compound_attributes' in event:
            for attr in event['compound_attributes']:
                compounds.append(attr)
        if len(compounds) > 0:
            # parse item and replace with '' if 'None'
            parsed_item = {k: (v if v else '') for k, v in event['Item'].items()}
            # run through and replace each attribute
            for attr in compounds:
                attr_name = attr['name']
                attr_format = attr['format']
                logger.info(f'attr_name/attr_format : {attr_name}/{attr_format}')

                # check to see that all attributes really are in our parsed_item!!!! (really good idea)
                requireds = re.findall("{(.*?)}", attr_format)
                for key in requireds:
                    if key not in parsed_item:
                        raise ValueError(f"ERROR: missing item for compound attribute! attribute: '{attr_name}', format: '{attr_format}', missing key: '{key}'")

                item[attr_name] = attr_format.format(**parsed_item)
                logger.info(f" - compound generated: '{attr_name}' = {item[attr_name]} (format = '{attr_format}')")

        ##########################
        # clear out blank values
        item = {k: v for k, v in item.items() if v != '' and v is not None}

        ###################################
        # transform item to dynamodb json
        item = json_d.dumps(item)
        item = json.loads(item)

        # logger.debug(json.dumps(item, indent=4))

        response = db.put_item(
            TableName=event['TableName'],
            Item=item,
            ReturnValues='NONE',
            ReturnConsumedCapacity='TOTAL'
        )

        # logger.info(response)

        statuscode = response['ResponseMetadata']['HTTPStatusCode']
        
        if statuscode == 200:
            return self.nu_response(True, None, newid)
        else:
            raise Exception(statuscode)

    def update_entity(self, event, context):
        """
        Update an item in the database
        NOTE: keeps createdon/updatedon from original
        """

        # logger.info("'update' called. event: {0}".format(json.dumps(event, cls=CommonEncoder, indent=4)))

        if 'userid' not in event:
            raise Exception('userid not provided')

        if 'Key' not in event:
            raise Exception("'Key' not specified")

        db = self.get_db_client()

        item = event['Item']

        #####
        # get old item and propagate created on / updated on
        # retrieve item first
        get_params = {
            'TableName': event['TableName'],
            'Key': event['Key'],
        }
        print(get_params)
        ret = db.get_item(**get_params)

        if 'Item' not in ret:
            return self.nu_response(False, 'Item not found')

        old_item = ret['Item']

        # logger.debug("old item retrieved: {0}".format(json.dumps(old_item, cls=CommonEncoder, indent=4)))

        self.update_meta(old_item, item, event['userid'])

        #########################
        # clear out blank values
        item = {k: v for k, v in item.items() if v != '' and v is not None}

        #######################################
        # check mandatory fields if specified
        if 'RequiredFields' in event:
            for field in event['RequiredFields']:
                if field not in item:
                    raise ValueError(f"Required field missing from item: {field}")

        ##################################
        # transform item to dynamodb json
        item = json_d.dumps(item)
        item = json.loads(item)

        # logger.debug("updated item:\n{0}".format(json.dumps(item, cls=CommonEncoder, indent=4)))

        response = db.put_item(
            TableName=event['TableName'],
            Item=item,
            ReturnValues='NONE',
            ReturnConsumedCapacity='TOTAL'
        )

        # logger.debug("Response: {0}".format(json.dumps(response, cls=CommonEncoder, indent=4)))

        success = response['ResponseMetadata']['HTTPStatusCode'] == 200

        return self.nu_response(success)

    def get_entity(self, event, context):
        """
        Given a key, retrieve the entity
        """

        # logger.info("'get' called. event: {0}".format(json.dumps(event, cls=CommonEncoder, indent=4)))

        if 'userid' not in event:
            return self.nu_response(False, 'userid not provided')

        db = self.get_db_client()

        ret = db.get_item(
            TableName=event['TableName'],
            Key=event['Key'],
            ReturnConsumedCapacity="TOTAL"
        )

        # logger.info(ret)

        httpcode = ret['ResponseMetadata']['HTTPStatusCode']
        if httpcode != 200:
            return self.nu_response(False, httpcode)

        print(ret)
        print("-------->>>> GO3")
        # check for item not found
        if 'Item' not in ret:
            return self.nu_response(False, "Item not found")

        jstr = json.dumps(ret['Item'])

        item = json_d.loads(jstr)
        if 'deleted' in item:
            if item['deleted']:
                return self.nu_response(False, "Item not found")

        return self.nu_response(True, None, item)

    def list_entities(self, event):
        """
        Retrieve a list of entities
            - with primary key - only for that [portal, etc] (query)
            - without primary key - everything (scan)
        """

        # logger.info("'list' called. event: {0}".format(json.dumps(event, indent=4)))

        if 'userid' not in event:
            return self.nu_response(False, 'userid not provided')

        db = self.get_db_resource()

        tbl = db.Table(event['TableName'])
        ret = None

        get_params = {
            'FilterExpression': "attribute_not_exists(deleted) or deleted = :delcol",
            'ReturnConsumedCapacity': "TOTAL",
            # "ExpressionAttributeValues": { ":delcol": { "BOOL": False  } }
        }
        if "ExpressionAttributeValues" in event:
            get_params['ExpressionAttributeValues'] = event['ExpressionAttributeValues']
            get_params["ExpressionAttributeValues"].update({":delcol": False})
        else:
            get_params['ExpressionAttributeValues'] = {":delcol": False}

        if 'KeyConditionExpression' in event:
            get_params['KeyConditionExpression'] = event['KeyConditionExpression']
            if 'ExpressionAttributeValues' in event:
                get_params['ExpressionAttributeValues'] = event['ExpressionAttributeValues']
            if 'ExpressionAttributeNames' in event:
                get_params['ExpressionAttributeNames'] = event['ExpressionAttributeNames']
            if 'FilterExpression' in event:
                get_params['FilterExpression'] = event['FilterExpression']
            if 'IndexName' in event:
                get_params['IndexName'] = event['IndexName']
            if 'ScanIndexForward' in event:
                get_params['ScanIndexForward'] = event['ScanIndexForward']
            if 'Limit' in event:
                get_params['Limit'] = event['Limit']
        if 'override' in event:
            print("*******------>>>")
            print(get_params)
            raise
            # logger.debug("About to call query with:\n{0}".format(json.dumps(get_params, indent=4)))
        AdminIn = False
        print(get_params['FilterExpression'])
        print(get_params['ExpressionAttributeValues'])
        skipAuth = False
        rcopy = []

        filtered = False
        items = self.listDynamoEntities(event, tbl, get_params)

        return json_d.loads(items, as_dict=True)

    def listDynamoEntities(self, event, tbl, get_params, lastKey=None, attempts=0):
        items = []
        DEBUG = True
        # if 'parse_source' in event:
        #     DEBUG=True
        attempts = attempts + 1
        if lastKey:
            if 'Keys' in get_params:  # Then its a batch call
                get_params['Keys'] = lastKey
            else:
                get_params.update({'ExclusiveStartKey': lastKey})

            # if hasattr(tbl, '_name'):  # Then its a batch call
            #     get_params['Keys'] = lastKey
            # else:
            #     get_params.update({'ExclusiveStartKey': lastKey})
        if DEBUG:
            print("~~~~~~~~~~~~~~")
            print(get_params)
            print("~~~~~~~~~~~~~~")
        if 'KeyConditionExpression' in event or "Looper" in event:
            if 'ConsistentRead' in event:
                get_params.update({'ConsistentRead': True})
            # print("~~~~~~~~~~~~~~")
            # print(get_params)
            # print("~~~~~~~~~~~~~~")
            # {'FilterExpression': 'attribute_not_exists(deleted)', 'ReturnConsumedCapacity': 'TOTAL', 'KeyConditionExpression': 'PK = :portalid AND begins_with(#keyName, :str)',  'ExpressionAttributeNames':{ "#keyName": "LSI-SK" },
            #                        'ExpressionAttributeValues': {':portalid': '_assigned', ':str': 'clientuser_21#'}, 'IndexName': 'PK-LSI-SK-index'}
            print("[W] query start-->")
            ret = tbl.query(**get_params)
        elif 'RequestItems' in event:
            print("[W] batch start-->")
            ret = tbl.batch_get_item(**get_params)
        else:
            print("[W] scan start-->")
            ret = tbl.scan(**get_params)
        # logger.info("Returned:\n{0}".format(ret))
        # print("Returned:%s"%(ret))
        print("DONE....")
        httpcode = ret['ResponseMetadata']['HTTPStatusCode']
        if httpcode != 200:
            return None
        if 'RequestItems' in event and "Looper" not in event:
            print(ret)
            items = ret['Responses'][event['TableName']]
        else:
            items = ret['Items']

        Limit = None
        if "Limit" in get_params:
            Limit = get_params['Limit']
            if len(items) >= Limit:
                return items
        # items = [i for i in ret['Items']]
        if 'LastEvaluatedKey' in ret:
            if ret['LastEvaluatedKey']:
                if attempts < 4:
                    time.sleep(0.2 ** attempts)
                items = items + self.listDynamoEntities(event, tbl, get_params, ret['LastEvaluatedKey'], attempts)
        elif 'UnprocessedKeys' in ret:
            if ret['UnprocessedKeys']:
                if attempts < 4:
                    time.sleep(0.2 * attempts)
                items = items + self.listDynamoEntities(event, tbl, get_params, ret['UnprocessedKeys'], attempts)

        return items

    #####################################
    # region helper functions
    #####################################

    def getcounter(self, tablename):
        # logger.info("About to generate new key for tablename {}".format(tablename))
        db = self.get_db_client()
        response = db.update_item(
            TableName='cn_counters',
            Key={'countername': {'S': tablename.lower()}},
            UpdateExpression='SET #s=#s + :val',
            ExpressionAttributeNames={'#s': 'value'},
            ExpressionAttributeValues={':val': {'N': '1'}},
            ReturnValues='UPDATED_NEW',
            ReturnConsumedCapacity='TOTAL',
        )
        logger.debug("results of attribute generation:")
        # logger.debug(json.dumps(response))

        if response['ResponseMetadata']['HTTPStatusCode'] != 200:
            raise "Error happened"

        return int(response['Attributes']['value']['N'])

    def get_db_client(self):
        if self.client is None:
            self.client = boto3.client('dynamodb') if not self.DEBUG else \
                boto3.client('dynamodb', region_name='us-east-1', endpoint_url="http://localhost:8000")
        return self.client

    def get_db_resource(self):
        return boto3.resource('dynamodb') if not self.DEBUG else \
            boto3.resource('dynamodb', region_name='us-east-1', endpoint_url="http://localhost:8000")

    def update_meta(self, old_item, item, userid):
        """
        overwrite created on/by with original info, as well as tag with updates
        """

        ###########
        # overwrite properties (convert to projer json first)

        # convert old item to regular json
        tmpitem = json.dumps(old_item)
        tmpitem = json_d.loads(tmpitem)
        # copy over all extra attributes that are carried over without being overwritten
        for k, v in tmpitem.items():
            if k not in item:
                item[k] = v

        # overwrite created on/by with original info
        item['createdon'] = int(old_item['createdon']['N'])
        item['createdby'] = int(old_item['createdby']['N'])

        # tag with metadata
        item['updatedon'] = int(datetime.datetime.utcnow().timestamp())
        item['updatedby'] = userid

    def nu_response(self, success=True, message=None, values=None):
        return {
            'success': success,
            'message': message,
            'value': values
        }
