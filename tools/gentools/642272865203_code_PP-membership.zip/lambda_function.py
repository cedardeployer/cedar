#!/usr/bin/python
from __future__ import print_function
import os
import sys
import re
import logging
import json
import boto3
import datetime
# import pytz
#from slacker import Slacker
#import unidecode
from botocore.exceptions import ClientError
# from datetime import date, datetime
from dynamo_entity import DynamoEntity
from boto3.dynamodb.conditions import Key, Attr

from nu_util import setup_sentry
setup_sentry()

# list/{state}/{expirationDate}  Find member by state and expirationDate
# lastname/{state}/{lastName}    Find member by state and lastname
# get/{state}/{membershipId}     Find member by membershipId and state


# logs PK = "membership_logs_open"   ""
# members PK = "membership_members_open"
# keys PK = "membership_keys_open"
xml_root = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
xml_wrap = ['<membership>', '</membership>']
response_message = "<message>%s</message>"
response_http = "<httpStatus>%s</httpStatus>"
response_datetime = "<dateTime>%s</dateTime>"
response_wrap = ['<response>', '</response>']
xml_list = 'members'
xml_single = 'membership'
notFound = "item not found"
nodes = {"membershipId": ["<membershipId>", "</membershipId>"], "state": ["<state>", "</state>"],
         "effectiveDate": ["<effectiveDate>", "</effectiveDate>"], "lastName": ["<lastName>", "</lastName>"],
         "expirationDate": ["<expirationDate>", "</expirationDate>"], "membershipType": ["<membershipType>", "</membershipType>"]}
outNodes = {"effectiveDate": "effective_date", "expirationDate": "expiration_date", "membershipType": "membership_type",
            "lastName": "lastname", "membershipId": "membershipid"}
responses = {"member_exist": "Member already exists",
             "member_exists_add": "Member cannot be created. Member already exists.",
             "member_exist_db": "Member already exists in database",
             "member_state_exception": "Exception in persisting member in database",
             "member_not_exist": "Member does not exist",
             "member_not_found": "Member not found",
             "bad_request": "Application error occurred. Error details are captured internally."
             }


def extract_inline(str_base, strFrom, strTo):
    print("%s   %s   %s" % (str_base, strFrom, strTo))
    index_from = str_base.find(strFrom)
    index_from = index_from + len(strFrom)
    index_to = str_base.find(strTo, index_from)
    last = str_base[index_from:index_to]
    return last.strip()


class MemberShipAPI():
    dynamo_logs = "pp_activity_logs"
    dynamo_table = "pp_membership_api"
    membersPK = "membership_members"
    date_format = '%Y-%m-%d'
    date_query_format = '%m-%d-%Y'
    date_format_now = '%Y-%m-%dT%H:%M:%S.000Z'
    de = None
    epoch = None
    dynamo_resource = None

    def __init__(self):
        self.de = DynamoEntity()
        self.epoch = int(datetime.datetime.utcnow().timestamp())

    def _resource(self):
        if self.dynamo_resource:
            return self.dynamo_resource
        self.dynamo_resource = boto3.resource('dynamodb')
        return self.dynamo_resource

    def unravel(self, xml):
        global nodes, outNodes
        obj = {}
        for k, v in nodes.items():
            nstr = extract_inline(xml, v[0], v[1])
            if 'date' in k.lower():
                dt = datetime.datetime.strptime(nstr, self.date_format)
                nstr = int(dt.timestamp())
            key = k
            if k in outNodes:
                key = outNodes[k]
            obj.update({key: nstr})
        return obj

    def epoch_to_format(self, value, format):
        if isinstance(value, datetime.date):
            dz = value
        else:
            # dz = datetime.datetime.fromtimestamp(value, pytz.utc)
            dz = datetime.datetime.utcfromtimestamp(value)
        return dz.strftime(format)

    def xml_single_wrap(self, obj, single=False):
        global xml_root, xml_wrap, nodes, xml_single

        if single:
            xml = xml_root
        else:
            xml = ""
        subWrap = xml_single if single else xml_list
        xml = xml + "<%s>" % subWrap

        for k, v in nodes.items():
            if k in obj:
                value = obj[k]
            else:
                value = obj[outNodes[k]]
            if 'date' in k.lower():
                print("...DATE %s" % (k))
                value = self.epoch_to_format(value, self.date_format)
            xml = xml + v[0] + str(value) + v[1]
        if single:
            cdate = self.epoch_to_format(obj['createdon'], self.date_format_now)
            xml = xml + "<createdDate>" + cdate + "</createdDate>"
        xml = xml + "</%s>" % subWrap
        return xml

    def xml_multi_wrap(self, members):
        global xml_root, xml_wrap, nodes
        xml = xml_root
        xml = xml + xml_wrap[0]
        for obj in members:
            xml = xml + self.xml_single_wrap(obj, False)
        xml = xml + xml_wrap[1]
        return xml

    def set_response(self, addl, error=None):  # Error, Bad Request, OK
        global responses, xml_root, response_wrap, response_message, response_http, response_datetime
        if addl in responses:
            addl = responses[addl]
        if not error:
            msg = "OK"
        elif "ok" in error.lower():
            msg = "OK"
        else:
            msg = error.capitalize()

        if "member_added" in addl:
            httpStatus = "Member Added"
        elif "already exist" in addl.lower():
            httpStatus = "302"
        elif "error occurred" in addl.lower():
            httpStatus = "Error"
        else:
            httpStatus = "404"
        dt = self.epoch_to_format(self.epoch, self.date_format_now)
        response = xml_root
        response = response + response_wrap[0]
        response = response + response_message % (msg)
        response = response + response_http % (httpStatus)
        response = response + response_datetime % (dt)
        if error and error.lower() != "ok":
            response = response + "<additional>%s</additional>" % (addl)
        response = response + response_wrap[1]
        return response

    def update_member(self, newObj):
        key = {
            "PK": {"S": "%s_open" % (self.membersPK)},
            "SK1": {"S": newObj['membershipid']}
        }
        newObj.update({
            "SK1": newObj['membershipid'],
            "LSI-SK": newObj['membershipid'],
            "requesttimestamp": self.epoch
        })
        event = {"TableName": self.dynamo_table, "action": "update",
                 "userid": 0, "Key": key, "Item": newObj
                 }
        result = self.de.update_entity(event)
        if result['value']:
            all_mems = self.xml_single_wrap(newObj)
        else:
            all_mems = self.set_response("member_not_found", "error")
        return all_mems

    def add_member(self, newObj):
        membershipid = newObj['membershipid']
        newObj.update({
            "PK": f"{self.membersPK}_open",
            "SK1": membershipid,
            "LSI-SK": membershipid,
            "requesttimestamp": self.epoch
        })
        obj = {"TableName": self.dynamo_table, 'userid': 0,
               "action": "create",
               # "autogen": {  "attribute_name": "roleid" },"CounterTable": "cn_roles",
               # "compound_attributes": [
               #     {"name": "PK", "format": f"{self.membersPK}_open"},
               #     {"name": "SK1", "format": newObj['membershipid']},
               #     {"name": "LSI-SK", "format": newObj['membershipid']},
               #     {"name": "requesttimestamp", "format": self.epoch}
               # ],
               "Item": newObj}
        print("_______+_________")
        print(newObj)
        existing = self.get_member(newObj['state'], membershipid, 'json/string')
        if notFound not in existing:
            return self.set_response("member_exists_add", "error")
        else:
            result = self.de.create_entity(obj, None)
            if 'success' in result:
                if result['success']:
                    uid = result['value']
                    result = uid
                    return self.set_response("member_added", "OK")
                else:
                    return self.set_response("bad_request", "error")
            else:
                msg = "[E] error occured, might already exist,  for membershipid:%s" % (membershipid)
                print(msg)
                all_mems = self.set_response("member_not_found", "error")
        return all_mems

    def delete_member(self, newObj):
        table = self._resource().Table(self.dynamo_table)
        memberid = newObj['membershipid']
        response = table.delete_item(Key={'PK': "%s_open" % (self.membersPK),
                                          'SK1': memberid})
        print(response)

    def get_member(self, state, memberid, response_type=None):
        global notFound
        tbl = self._resource().Table(self.dynamo_table)
        pkCombined = "%s_open" % (self.membersPK)
        results = {}
        indexName = "get_by_membershipid"
        try:
            results = tbl.query(IndexName=indexName,
                                KeyConditionExpression=Key('PK').eq(pkCombined) & Key('membershipid').eq(memberid),
                                # KeyConditionExpression=Key('PK').eq(pkCombined) & Key('SK1').begins_with(combined),
                                FilterExpression=Attr('deleted').ne(True) | Attr('deleted').not_exists() & Attr('state').eq(state)
                                )
        except ClientError as ex:
            msg = "[E] -GET-  DynamoDB get of LSI-SK:%s  error:%s" % (pkCombined, ex)
            print(msg)
            if not response_type:
                all_mems = self.set_response("member_not_found", "error")
            else:
                return notFound
        if 'Items' in results:
            if not response_type:
                if results['Items']:
                    all_mems = self.xml_single_wrap(results['Items'][0], True)
                else:
                    all_mems = self.set_response("member_not_found", "error")
            else:
                return results['Items'] if results['Items'] else notFound
        else:
            if not response_type:
                all_mems = self.set_response("member_not_found", "error")
            else:
                return notFound
        # print (all_mems)
        # print("......")
        return all_mems

    def query_members(self, key, value, state='va'):
        event = {"action": "list"}
        if 'lastname' in key:
            indexName = "get_by_lastname"
            condition = "PK = :pk AND lastname = :str)"
        else:  # assume its for expiration date 12-31-2022 MM-dd-yyyy
            indexName = "get_by_expiredate"
            condition = "PK = :pk AND expiration_date <= :str"
            dt = datetime.datetime.strptime(value, self.date_query_format)
            value = str(int(dt.timestamp()))

        dynamic = False
        if isinstance(value, str):
            if "*" in value:
                print("++> D Y N A M I C")
                value = value[0:-1]
                dynamic = True
        event = {"action": "list",
                 "TableName": self.dynamo_table,
                 "userid": 0,
                 "IndexName": indexName,
                 "KeyConditionExpression": condition,
                 "FilterExpression": "attribute_not_exists(deleted) or deleted = :delcol and #ss=%s" % state,
                 "ExpressionAttributeValues": {
                     ":pk": "%s_open" % self.membersPK,
                     ":str": value
                 },
                 "ExpressionAttributeNames": {"#ss": "state"}
                 }
        if dynamic:
            event.update({"KeyConditionExpression": "PK = :pk AND begins_with(lastname, :str)"})
        print(event)

        result = self.de.list_entities(event)
        print(result)
        if result:
            all_mems = self.xml_multi_wrap(result)
        else:
            all_mems = self.set_response("member_not_found", "error")
        # print (all_mems)
        # print("......")
        return all_mems


def lambda_handler(event, context, test=False):
    print(event)
    ms = MemberShipAPI()
    action = event['action']
    if 'Item' in event:
        xml = event['Item']
        if xml:
            obj = ms.unravel(xml)
        else:
            return "[E] xml data not found in Item"
    print("---process---%s" % (action))
    if 'update' in action:
        state = event['state']
        memberid = event['memberid']
        return ms.update_member(obj)
    elif 'create' in action:
        return ms.add_member(obj)
    elif 'query' in action:
        key = event['key']
        state = event['state']
        value = event['value']
        return ms.query_members(key, value)
    elif 'get' in action:
        state = event['state']
        memberid = event['memberid']
        return ms.get_member(state, memberid)
    elif 'delete' in action:
        return ms.delete_member(newObj)
    else:
        ms.set_response("member_state_exception", "error")


if __name__ == '__main__':
    test = True
